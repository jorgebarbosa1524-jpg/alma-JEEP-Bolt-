/**
 * Cliente direto da API do Gemini (Google AI Studio), usado quando o app roda sem backend
 * (GitHub Pages, multimídia). A chave é digitada em Configurações e fica SÓ neste aparelho
 * (IndexedDB); nunca vai para o GitHub nem para o backup exportado.
 *
 * Três usos: voz (TTS → áudio WAV tocado como mídia comum), transcrição do microfone e conversa.
 * Cada uso tenta uma lista de modelos em ordem e lembra o primeiro que funcionou.
 */

const BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

export const TTS_MODELS = ['gemini-3.8-flash-lite-tts', 'gemini-3.8-flash-tts', 'gemini-3.1-flash-tts-preview'];
export const TEXT_MODELS = ['gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];

/** Vozes prontas do Gemini (nome → característica, traduzida). */
export const GEMINI_VOICES = [
  ['Charon', 'informativa, grave'], ['Orus', 'firme'], ['Algenib', 'rouca'], ['Alnilam', 'firme'], ['Gacrux', 'madura'],
  ['Iapetus', 'clara'], ['Rasalgethi', 'informativa'], ['Sadaltager', 'sábia'], ['Schedar', 'equilibrada'], ['Umbriel', 'tranquila'],
  ['Fenrir', 'animada'], ['Puck', 'alegre'], ['Achird', 'amigável'], ['Zubenelgenubi', 'descontraída'], ['Enceladus', 'suave, sussurrada'],
  ['Kore', 'firme (feminina)'], ['Zephyr', 'brilhante (feminina)'], ['Aoede', 'leve (feminina)'], ['Leda', 'jovem (feminina)'], ['Sulafat', 'calorosa (feminina)'],
  ['Despina', 'macia (feminina)'], ['Vindemiatrix', 'gentil (feminina)'], ['Achernar', 'suave (feminina)'], ['Autonoe', 'brilhante (feminina)'], ['Callirrhoe', 'tranquila (feminina)'],
  ['Erinome', 'clara (feminina)'], ['Laomedeia', 'alegre (feminina)'], ['Pulcherrima', 'direta (feminina)'], ['Sadachbia', 'viva (feminina)'], ['Algieba', 'macia'],
];

/** Estilo de fala de cada personalidade (vai junto com o texto para o Gemini). */
export const VOICE_STYLES = {
  imponente: 'grave, solene, pausada e confiante, como um robô gigante leal',
  debochado: 'bem-humorada, irônica e descontraída',
  friendly: 'calorosa, clara e simpática',
  professional: 'objetiva, calma e profissional',
  fun: 'leve, animada e divertida',
};

export class GeminiError extends Error {
  constructor(code, message, status = 0) {
    super(message);
    this.name = 'GeminiError';
    this.code = code;
    this.status = status;
  }
}

/** Erros que não adianta tentar em outro modelo (chave errada, cota, rede). */
const FATAL = new Set(['BAD_KEY', 'NO_KEY', 'QUOTA', 'NETWORK', 'TIMEOUT', 'ABORTED']);

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function bytesToB64(bytes) {
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}

/** Embrulha PCM 16 bits mono num arquivo WAV que qualquer <audio> toca. */
export function pcmToWav(pcm, sampleRate = 24000, channels = 1) {
  const buf = new ArrayBuffer(44 + pcm.length);
  const v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + pcm.length, true); w(8, 'WAVE');
  w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, channels, true);
  v.setUint32(24, sampleRate, true); v.setUint32(28, sampleRate * channels * 2, true); v.setUint16(32, channels * 2, true); v.setUint16(34, 16, true);
  w(36, 'data'); v.setUint32(40, pcm.length, true);
  new Uint8Array(buf, 44).set(pcm);
  return new Uint8Array(buf);
}

/** Converte o inlineData devolvido pelo Gemini em bytes WAV (já vem WAV nos modelos novos; PCM cru nos antigos). */
export function audioPartToWav({ mimeType = '', data = '' }) {
  const bytes = b64ToBytes(data);
  const isWav = bytes.length > 12 && bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46;
  if (isWav || /wav/i.test(mimeType)) return bytes;
  const rate = Number((/rate=(\d+)/i.exec(mimeType) || [])[1]) || 24000;
  return pcmToWav(bytes, rate);
}

export class GeminiClient {
  /** @param {{getKey:()=>string, fetchFn?:typeof fetch}} deps */
  constructor({ getKey, fetchFn = (...a) => fetch(...a) }) {
    this.getKey = getKey;
    this.fetch = fetchFn;
    this.working = { tts: null, text: null }; // { model, schema }
    this.lastError = null;
  }

  get hasKey() {
    return !!String(this.getKey() || '').trim();
  }

  async #call(model, body, { signal, timeoutMs = 20000 } = {}) {
    const key = String(this.getKey() || '').trim();
    if (!key) throw new GeminiError('NO_KEY', 'Chave do Gemini não configurada.');
    const ctl = new AbortController();
    const onAbort = () => ctl.abort();
    signal?.addEventListener('abort', onAbort);
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    let res;
    try {
      res = await this.fetch(`${BASE}/${encodeURIComponent(model)}:generateContent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify(body),
        signal: ctl.signal,
      });
    } catch (err) {
      if (signal?.aborted) throw new GeminiError('ABORTED', 'Cancelado.');
      if (err?.name === 'AbortError') throw new GeminiError('TIMEOUT', 'O Gemini demorou demais para responder.');
      throw new GeminiError('NETWORK', 'Sem conexão com o Gemini (confira a internet).');
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = String(j?.error?.message || '');
      const reason = JSON.stringify(j?.error?.details || '');
      if (/API_KEY_INVALID|API key not valid/i.test(msg + reason) || res.status === 401) throw new GeminiError('BAD_KEY', 'A chave do Gemini é inválida.', res.status);
      if (res.status === 403) throw new GeminiError('BAD_KEY', 'A chave do Gemini não tem permissão para este recurso.', res.status);
      if (res.status === 429) throw new GeminiError('QUOTA', 'Limite de uso do Gemini atingido. Tente mais tarde.', res.status);
      if (res.status === 404) throw new GeminiError('NO_MODEL', `Modelo ${model} indisponível.`, res.status);
      throw new GeminiError('HTTP', msg || `Erro do Gemini (HTTP ${res.status}).`, res.status);
    }
    return j;
  }

  /** Percorre os modelos até um funcionar. tries: [{model, schema}] */
  async #firstWorking(kind, tries, run) {
    const remembered = this.working[kind];
    const list = remembered ? [remembered, ...tries.filter((t) => t.model !== remembered.model || t.schema !== remembered.schema)] : tries;
    let last = null;
    for (const t of list) {
      try {
        const out = await run(t);
        this.working[kind] = t;
        this.lastError = null;
        return out;
      } catch (err) {
        last = err;
        if (err instanceof GeminiError && FATAL.has(err.code)) break;
      }
    }
    this.lastError = last;
    throw last || new GeminiError('HTTP', 'Gemini indisponível.');
  }

  /**
   * Gera a fala. Retorna Uint8Array com um WAV.
   * @param {string} text
   * @param {{voice?:string, style?:string, model?:string, signal?:AbortSignal}} opts
   */
  async speech(text, { voice = 'Charon', style = '', model = '', signal } = {}) {
    const models = model ? [model, ...TTS_MODELS.filter((m) => m !== model)] : TTS_MODELS;
    // esquema novo (3.8: voiceConfig.voice + speech_metadata) e antigo (prebuiltVoiceConfig)
    const tries = [];
    for (const m of models) {
      const order = /^gemini-3\.[8-9]|^gemini-[4-9]/.test(m) ? ['new', 'old'] : ['old', 'new'];
      for (const schema of order) tries.push({ model: m, schema });
    }
    const say = String(text).slice(0, 600);
    return this.#firstWorking('tts', tries, async ({ model: m, schema }) => {
      const body = schema === 'new'
        ? { contents: [{ role: 'user', parts: [{ text: say, ...(style ? { speech_metadata: { style: `${style}; português do Brasil` } } : {}) }] }],
            generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { voice } } } }
        : { contents: [{ role: 'user', parts: [{ text: style ? `Fale em português do Brasil, com voz ${style}: ${say}` : say }] }],
            generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } } } };
      const j = await this.#call(m, body, { signal, timeoutMs: 20000 });
      const part = j?.candidates?.[0]?.content?.parts?.find((p) => p.inlineData || p.inline_data);
      const data = part?.inlineData || part?.inline_data;
      if (!data?.data) throw new GeminiError('EMPTY', 'O Gemini não devolveu áudio.');
      return audioPartToWav({ mimeType: data.mimeType || data.mime_type || '', data: data.data });
    });
  }

  /** Pergunta de texto. Retorna a resposta (string). */
  async ask(prompt, { model = '', signal, temperature = 0.8 } = {}) {
    const models = model ? [model, ...TEXT_MODELS.filter((m) => m !== model)] : TEXT_MODELS;
    return this.#firstWorking('text', models.map((m) => ({ model: m, schema: 'text' })), async ({ model: m }) => {
      const j = await this.#call(m, { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature, maxOutputTokens: 1024 } }, { signal, timeoutMs: 25000 });
      const text = (j?.candidates?.[0]?.content?.parts || []).filter((p) => p.text && !p.thought).map((p) => p.text).join(' ').trim();
      if (!text) throw new GeminiError('EMPTY', 'O Gemini não respondeu.');
      return text;
    });
  }

  /** Transcreve um áudio gravado (Blob) para texto em português. */
  async transcribe(blob, { signal } = {}) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const mime = (blob.type || 'audio/webm').split(';')[0];
    const prompt = 'Transcreva exatamente o que a pessoa fala neste áudio, em português do Brasil. Responda somente com a transcrição, sem aspas e sem comentários. Se não houver fala, responda com um texto vazio.';
    return this.#firstWorking('stt', TEXT_MODELS.map((m) => ({ model: m, schema: 'stt' })), async ({ model: m }) => {
      const j = await this.#call(m, { contents: [{ role: 'user', parts: [{ text: prompt }, { inlineData: { mimeType: mime, data: bytesToB64(bytes) } }] }], generationConfig: { temperature: 0 } }, { signal, timeoutMs: 20000 });
      return (j?.candidates?.[0]?.content?.parts || []).filter((p) => p.text && !p.thought).map((p) => p.text).join(' ').trim();
    });
  }
}
