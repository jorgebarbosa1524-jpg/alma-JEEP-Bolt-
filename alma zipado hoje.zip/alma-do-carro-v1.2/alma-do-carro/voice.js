/**
 * Voz do assistente, com dois motores de fala e dois de escuta:
 *
 *  FALA
 *   - nuvem (Gemini TTS): o texto vira um arquivo de áudio e toca como mídia comum (igual YouTube/rádio).
 *     Não depende de nenhum motor de voz instalado na multimídia. Precisa de internet e da chave.
 *     Falas curtas e repetidas (alertas, reações) ficam guardadas e tocam até sem internet.
 *   - aparelho (SpeechSynthesis): o motor de voz do Android. No celular costuma existir; em muitas
 *     multimídias não existe, e a fala falha em silêncio.
 *   Modo "auto": nuvem quando há chave e internet; se falhar, tenta o aparelho.
 *
 *  ESCUTA
 *   - reconhecimento do navegador (SpeechRecognition), com escuta contínua pelo nome;
 *   - nuvem: grava a frase com o microfone e o Gemini transcreve (só no modo "toque para falar").
 */
import { Emitter } from './events.js';
import { VOICE_STYLES } from './gemini.js';

const norm = (s) =>
  String(s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

/** Extrai o comando após a palavra de ativação (ex.: "ei bolt, qual a temperatura"). */
// o reconhecimento de voz erra o nome de formas previsíveis; estas variações também ativam a alma
const WAKE_ALIASES = { bolt: ['bolte', 'volt', 'bolti', 'boult', 'boldi', 'bout'] };

export function extractAfterWake(transcript, wakeName) {
  const t = ` ${norm(transcript)} `;
  const w = norm(wakeName);
  if (!w) return null;
  let at = -1;
  let len = 0;
  for (const a of [w, ...(WAKE_ALIASES[w] || [])]) {
    const i = t.indexOf(` ${a} `);
    if (i >= 0 && (at < 0 || i < at)) { at = i; len = a.length; }
  }
  if (at < 0) return null;
  return t.slice(at + 1 + len).replace(/^(,| )+/, '').trim();
}

/** WAV mudo de 0,05 s: tocado no primeiro toque para o Android liberar o áudio do app. */
const SILENT_WAV = 'data:audio/wav;base64,UklGRkQDAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YSADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==';

const CACHE_NAME = 'alma-voz-v1';
const CACHE_MAX_CHARS = 220; // só falas curtas (alertas, reações, saudações) são guardadas
const MEM_MAX = 40;

export class VoiceService extends Emitter {
  /** @param {{getSetting:(p:string,d?:any)=>any, env?:any, gemini?:import('./gemini.js').GeminiClient|null}} deps */
  constructor({ getSetting, env = globalThis, gemini = null }) {
    super();
    this.getSetting = getSetting;
    this.env = env;
    this.gemini = gemini;
    this.rec = null;
    this.listening = false;
    this.continuous = false;
    this.wantListening = false;
    this.restartDelay = 400;
    this.speaking = false;
    this.paused = false;
    this.armedUntil = 0;
    this.lastError = null;
    this.lastEngine = null; // 'cloud' | 'device'
    this.voices = [];
    this.audio = null;
    this.unlocked = false;
    this._gen = 0;
    this._ctl = null;
    this._mem = new Map();
    this._cloudFailUntil = 0;
    this._rec = null; // gravação para transcrição na nuvem
    const synth = env.speechSynthesis;
    if (synth) {
      const load = () => {
        this.voices = synth.getVoices();
        this.emit('voices', this.voices);
      };
      load();
      synth.onvoiceschanged = load;
    }
  }

  /* ------------------------------------------------------------------ capacidades */

  get deviceTtsSupported() {
    return !!(this.env.speechSynthesis && this.env.SpeechSynthesisUtterance);
  }
  get cloudTtsAvailable() {
    return !!(this.gemini?.hasKey && this.env.Audio);
  }
  get ttsSupported() {
    return this.deviceTtsSupported || this.cloudTtsAvailable;
  }
  get browserSttSupported() {
    return !!(this.env.SpeechRecognition || this.env.webkitSpeechRecognition);
  }
  get cloudSttAvailable() {
    return !!(this.gemini?.hasKey && this.env.navigator?.mediaDevices?.getUserMedia && this.env.MediaRecorder);
  }
  get sttSupported() {
    return this.browserSttSupported || this.cloudSttAvailable;
  }
  get online() {
    return this.env.navigator?.onLine !== false;
  }
  /** Qual motor de fala será usado agora. */
  get engine() {
    const pref = this.getSetting('assistant.voiceEngine', 'auto');
    if (pref === 'device') return this.deviceTtsSupported ? 'device' : null;
    if (pref === 'cloud') return this.cloudTtsAvailable ? 'cloud' : null;
    if (this.cloudTtsAvailable && this.online && Date.now() > this._cloudFailUntil) return 'cloud';
    return this.deviceTtsSupported ? 'device' : this.cloudTtsAvailable ? 'cloud' : null;
  }

  ptVoices() {
    return this.voices.filter((v) => /^pt/i.test(v.lang));
  }

  #canSpeak() {
    const ua = this.env.navigator?.userActivation;
    return !ua || ua.hasBeenActive || this.unlocked;
  }

  /**
   * Chamado no primeiro toque na tela: toca um som mudo para o Android liberar o áudio do app.
   * Sem isso, a multimídia bloqueia o primeiro áudio automático.
   */
  unlock() {
    if (this.unlocked) return;
    try {
      const a = this.#audioEl();
      if (a) {
        a.src = SILENT_WAV;
        const p = a.play();
        if (p?.then) p.then(() => { this.unlocked = true; }).catch(() => {});
        else this.unlocked = true;
      }
    } catch { /* ignora */ }
  }

  #audioEl() {
    if (this.audio) return this.audio;
    if (!this.env.Audio) return null;
    const a = new this.env.Audio();
    a.preload = 'auto';
    try { a.setAttribute?.('playsinline', ''); } catch { /* ignora */ }
    this.audio = a;
    return a;
  }

  arm(ms = 10000) {
    this.armedUntil = Date.now() + ms;
  }

  #pause() {
    if (!(this.continuous && this.wantListening) || this.paused) return;
    this.paused = true;
    try { this.rec?.abort(); } catch { /* ignora */ }
  }
  #resume() {
    if (!this.paused) return;
    this.paused = false;
    if (this.continuous && this.wantListening && !this.listening) setTimeout(() => { if (this.wantListening && !this.listening && !this.paused) this.#begin(); }, 300);
  }

  #setSpeaking(on) {
    if (this.speaking === on) return;
    this.speaking = on;
    this.emit('speaking', on);
    if (!on) this.#resume();
  }

  /* ------------------------------------------------------------------ fala */

  /**
   * Fala o texto pelo melhor motor disponível. Retorna true se tentou falar.
   * @param {string} text
   * @param {{interrupt?:boolean, engine?:'cloud'|'device'}} opts
   */
  speak(text, { interrupt = true, engine = null } = {}) {
    const t = String(text || '').trim();
    if (!t || !this.getSetting('assistant.voiceEnabled', true) || !this.#canSpeak()) return false;
    const eng = engine || this.engine;
    if (!eng) return false;
    if (eng === 'device') return this.#speakDevice(t, { interrupt });
    this.#speakCloud(t, { interrupt }).catch((err) => {
      if (err?.code === 'ABORTED') return;
      this.lastError = err?.message || 'falha na voz da nuvem';
      this.emit('ttserror', this.lastError);
      // modo automático: se a nuvem falhou, tenta o motor do aparelho e dá um tempo antes de insistir na nuvem
      if (this.getSetting('assistant.voiceEngine', 'auto') === 'auto') {
        if (err?.code !== 'PLAY') this._cloudFailUntil = Date.now() + (err?.code === 'BAD_KEY' ? 10 * 60000 : 60000);
        if (this.deviceTtsSupported) this.#speakDevice(t, { interrupt: true });
      }
    });
    return true;
  }

  #cacheKey(text, voice, style) {
    return `${voice}|${style}|${text}`;
  }

  async #cacheGet(key) {
    if (this._mem.has(key)) return this._mem.get(key);
    try {
      if (!this.env.caches) return null;
      const c = await this.env.caches.open(CACHE_NAME);
      const r = await c.match(`https://alma.voz/${encodeURIComponent(key)}`);
      if (!r) return null;
      const bytes = new Uint8Array(await r.arrayBuffer());
      this.#memPut(key, bytes);
      return bytes;
    } catch {
      return null;
    }
  }

  #memPut(key, bytes) {
    this._mem.set(key, bytes);
    if (this._mem.size > MEM_MAX) this._mem.delete(this._mem.keys().next().value);
  }

  async #cachePut(key, bytes, text) {
    this.#memPut(key, bytes);
    if (text.length > CACHE_MAX_CHARS) return;
    try {
      if (!this.env.caches) return;
      const c = await this.env.caches.open(CACHE_NAME);
      await c.put(`https://alma.voz/${encodeURIComponent(key)}`, new this.env.Response(bytes, { headers: { 'Content-Type': 'audio/wav' } }));
      const keys = await c.keys();
      for (const k of keys.slice(0, Math.max(0, keys.length - 300))) await c.delete(k);
    } catch { /* ignora */ }
  }

  /** Apaga as falas guardadas (Configurações). */
  async clearCache() {
    this._mem.clear();
    try { await this.env.caches?.delete(CACHE_NAME); } catch { /* ignora */ }
  }

  async #speakCloud(text, { interrupt }) {
    if (interrupt) this.#stopAll();
    const gen = ++this._gen;
    const voice = this.getSetting('assistant.cloudVoice', 'Charon') || 'Charon';
    const style = VOICE_STYLES[this.getSetting('assistant.personality', 'imponente')] || '';
    const key = this.#cacheKey(text, voice, style);
    // espera a fala anterior terminar quando não é para interromper
    if (!interrupt && this._playing) await this._playing.catch(() => {});
    if (gen !== this._gen) throw Object.assign(new Error('cancelado'), { code: 'ABORTED' });
    let wav = await this.#cacheGet(key);
    if (!wav) {
      if (!this.online) throw Object.assign(new Error('sem internet para a voz da nuvem'), { code: 'NETWORK' });
      this._ctl = new AbortController();
      this.emit('preparing', true);
      try {
        wav = await this.gemini.speech(text, { voice, style, model: this.getSetting('assistant.cloudModel', ''), signal: this._ctl.signal });
      } finally {
        this.emit('preparing', false);
        this._ctl = null;
      }
      if (gen !== this._gen) throw Object.assign(new Error('cancelado'), { code: 'ABORTED' });
      this.#cachePut(key, wav, text);
    }
    this.lastEngine = 'cloud';
    this._playing = this.#play(wav, gen);
    return this._playing;
  }

  #play(wav, gen) {
    return new Promise((resolve, reject) => {
      const a = this.#audioEl();
      if (!a) return reject(Object.assign(new Error('áudio indisponível'), { code: 'NO_AUDIO' }));
      const url = this.env.URL.createObjectURL(new this.env.Blob([wav], { type: 'audio/wav' }));
      let done = false;
      const finish = (err) => {
        if (done) return;
        done = true;
        a.onended = a.onerror = a.onpause = null;
        try { this.env.URL.revokeObjectURL(url); } catch { /* ignora */ }
        if (gen === this._gen) this.#setSpeaking(false);
        if (err) reject(err); else resolve();
      };
      a.onended = () => finish();
      a.onerror = () => finish(Object.assign(new Error('o áudio não pôde ser tocado'), { code: 'PLAY' }));
      a.onpause = () => { if (a.currentTime < (a.duration || Infinity) - 0.05) finish(); };
      a.src = url;
      a.volume = Math.min(1, Math.max(0, Number(this.getSetting('assistant.volume', 1))));
      const rate = Math.min(1.6, Math.max(0.6, Number(this.getSetting('assistant.cloudRate', 1)) || 1));
      a.playbackRate = rate;
      try { a.preservesPitch = true; } catch { /* ignora */ }
      this.#pause();
      this.#setSpeaking(true);
      const p = a.play();
      if (p?.catch) p.catch((e) => finish(Object.assign(new Error(e?.name === 'NotAllowedError' ? 'toque na tela para liberar o som' : 'o áudio não pôde ser tocado'), { code: 'PLAY' })));
      this.lastError = null;
    });
  }

  #stopAll() {
    this._gen++;
    try { this._ctl?.abort(); } catch { /* ignora */ }
    if (this.audio && !this.audio.paused) {
      try { this.audio.pause(); } catch { /* ignora */ }
    }
    try {
      const synth = this.env.speechSynthesis;
      if (synth && (synth.speaking || synth.pending)) synth.cancel();
    } catch { /* ignora */ }
  }

  #pickVoice() {
    const name = this.getSetting('assistant.voiceName', '');
    const byName = this.voices.find((v) => v.name === name);
    if (byName) return byName;
    const pt = this.ptVoices();
    const rank = (v) => (/br/i.test(v.lang) ? 0 : 2) + (v.localService ? 0 : 1);
    return [...pt].sort((x, y) => rank(x) - rank(y))[0] || null;
  }

  /**
   * Motor de voz do aparelho. Em multimídias Android (WebView) a síntese falha em silêncio por vários
   * motivos; aqui: só cancela se houver fala em andamento, guarda a referência, confere se a fala
   * começou e, se não começou ou deu erro, tenta de novo de forma simples.
   */
  #speakDevice(text, { interrupt = true, plain = false } = {}) {
    if (!this.deviceTtsSupported) return false;
    const synth = this.env.speechSynthesis;
    if (interrupt && this.audio && !this.audio.paused) { this._gen++; try { this.audio.pause(); } catch { /* ignora */ } }
    const busy = synth.speaking || synth.pending;
    if (interrupt && busy) synth.cancel();
    const u = new this.env.SpeechSynthesisUtterance(String(text).slice(0, 600));
    u.lang = 'pt-BR';
    const voice = this.#pickVoice();
    if (voice && !plain) {
      u.voice = voice;
      u.lang = voice.lang;
    }
    if (!plain) {
      u.rate = Math.min(2, Math.max(0.1, Number(this.getSetting('assistant.rate', 1)) || 1));
      u.pitch = Math.min(2, Math.max(0.1, Number(this.getSetting('assistant.pitch', 1)) || 1));
      u.volume = Math.min(1, Math.max(0, Number(this.getSetting('assistant.volume', 1))));
    }
    let started = false;
    let finished = false;
    u.onstart = () => {
      started = true;
      this.lastError = null;
      this.lastEngine = 'device';
      this.#setSpeaking(true);
    };
    const end = () => {
      if (finished) return;
      finished = true;
      clearTimeout(watchdog);
      this._u = null;
      this.#setSpeaking(false);
    };
    u.onend = end;
    u.onerror = (e) => {
      const err = e && e.error;
      if (err === 'interrupted' || err === 'canceled') return end();
      this.lastError = err || 'erro';
      this.emit('ttserror', this.lastError);
      end();
      if (!plain) setTimeout(() => this.#speakDevice(text, { interrupt: true, plain: true }), 150);
    };
    const watchdog = setTimeout(() => {
      if (started || finished) return;
      try { synth.cancel(); } catch { /* ignora */ }
      end();
      if (!plain) this.#speakDevice(text, { interrupt: false, plain: true });
      else { this.lastError = 'sem-som'; this.emit('ttserror', this.lastError); }
    }, 3000);
    this._u = u;
    this.#pause();
    clearTimeout(this._resumeT);
    this._resumeT = setTimeout(() => this.#resume(), Math.max(4000, String(text).length * 110 / Math.max(0.3, u.rate || 1)) + 3000);
    if (interrupt && busy) setTimeout(() => synth.speak(u), 90);
    else synth.speak(u);
    return true;
  }

  cancelSpeech() {
    this.#stopAll();
    this.#setSpeaking(false);
  }

  /* ------------------------------------------------------------------ escuta */

  /**
   * Inicia a escuta. mode "tap": uma frase. mode "continuous": fica ouvindo e só reage
   * quando ouve o nome do assistente (somente com o reconhecimento do navegador).
   */
  startListening({ mode = 'tap' } = {}) {
    if (this.browserSttSupported) {
      if (this.listening) return true;
      this.continuous = mode === 'continuous';
      this.wantListening = true;
      this.#begin();
      return true;
    }
    if (this.cloudSttAvailable) {
      if (mode === 'continuous') return false; // gravar sem parar gastaria a cota: só no toque
      if (this._rec) return true;
      this.#recordCloud();
      return true;
    }
    this.emit('error', { code: 'UNSUPPORTED', message: this.gemini?.hasKey ? 'Este aparelho não libera o microfone para o app.' : 'Reconhecimento de voz indisponível aqui. Cole a chave do Gemini em Configurações para ouvir pela nuvem.' });
    return false;
  }

  /** Grava uma frase (para sozinho depois de ~1,2 s de silêncio) e manda para o Gemini transcrever. */
  async #recordCloud() {
    const env = this.env;
    let stream;
    this._rec = { stopping: false };
    try {
      stream = await env.navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    } catch (err) {
      this._rec = null;
      const denied = err?.name === 'NotAllowedError' || err?.name === 'SecurityError';
      this.emit('error', { code: denied ? 'not-allowed' : 'audio-capture', message: denied ? 'Permissão de microfone negada.' : 'Nenhum microfone disponível.' });
      return;
    }
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    const mimeType = types.find((t) => env.MediaRecorder.isTypeSupported?.(t)) || '';
    let mr;
    try {
      mr = new env.MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    } catch {
      stream.getTracks().forEach((t) => t.stop());
      this._rec = null;
      this.emit('error', { code: 'START', message: 'Não foi possível gravar o microfone.' });
      return;
    }
    const chunks = [];
    const rec = this._rec;
    rec.mr = mr;
    mr.ondataavailable = (e) => { if (e.data?.size) chunks.push(e.data); };

    // detecção simples de fala/silêncio pelo volume
    let ac = null;
    let raf = null;
    const t0 = Date.now();
    let heardAt = 0;
    let lastLoud = 0;
    try {
      ac = new (env.AudioContext || env.webkitAudioContext)();
      const src = ac.createMediaStreamSource(stream);
      const an = ac.createAnalyser();
      an.fftSize = 1024;
      src.connect(an);
      const buf = new Uint8Array(an.fftSize);
      const loop = () => {
        if (rec.stopping) return;
        an.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) { const d = (buf[i] - 128) / 128; sum += d * d; }
        const rms = Math.sqrt(sum / buf.length);
        const now = Date.now();
        if (rms > 0.04) { lastLoud = now; if (!heardAt) heardAt = now; }
        if ((heardAt && now - lastLoud > 1300 && now - heardAt > 500) || (!heardAt && now - t0 > 7000) || now - t0 > 15000) return this.stopListening();
        raf = setTimeout(loop, 80);
      };
      loop();
    } catch {
      raf = setTimeout(() => this.stopListening(), 8000);
    }

    mr.onstop = async () => {
      clearTimeout(raf);
      try { ac?.close(); } catch { /* ignora */ }
      stream.getTracks().forEach((t) => t.stop());
      this.listening = false;
      this.emit('listening', false);
      this._rec = null;
      const blob = new env.Blob(chunks, { type: mr.mimeType || mimeType || 'audio/webm' });
      if (rec.cancel || blob.size < 1500) return;
      this.emit('transcribing', true);
      try {
        const text = await this.gemini.transcribe(blob);
        this.emit('transcribing', false);
        if (text) this.emit('result', { text, final: true });
        else this.emit('error', { code: 'no-speech', message: 'Não entendi. Toque no microfone e fale de novo.' });
      } catch (err) {
        this.emit('transcribing', false);
        this.emit('error', { code: 'cloud', message: `Não consegui ouvir pela nuvem: ${err?.message || 'erro'}` });
      }
    };
    this.#stopAll();
    this.#setSpeaking(false);
    mr.start(250);
    this.listening = true;
    this.emit('listening', true);
  }

  #begin() {
    const Rec = this.env.SpeechRecognition || this.env.webkitSpeechRecognition;
    const rec = new Rec();
    rec.lang = 'pt-BR';
    rec.interimResults = !this.continuous;
    rec.continuous = this.continuous;
    rec.maxAlternatives = 1;
    this.rec = rec;
    rec.onstart = () => {
      this.listening = true;
      this.emit('listening', true);
    };
    rec.onresult = (ev) => {
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const res = ev.results[i];
        const text = res[0].transcript;
        if (this.continuous) {
          if (!res.isFinal) continue;
          if (Date.now() < this.armedUntil && String(text).trim()) {
            this.armedUntil = 0;
            this.emit('result', { text: String(text).trim(), final: true, viaWake: true });
            continue;
          }
          const wake = this.getSetting('assistant.name', 'Bolt');
          const cmd = extractAfterWake(text, wake);
          if (cmd === null) continue;
          this.emit('wake', { command: cmd, transcript: text });
          if (cmd) this.emit('result', { text: cmd, final: true, viaWake: true });
        } else {
          this.emit('result', { text, final: res.isFinal });
          if (res.isFinal) this.wantListening = false;
        }
      }
    };
    rec.onerror = (ev) => {
      const map = {
        'not-allowed': 'Permissão de microfone negada.',
        'service-not-allowed': 'Reconhecimento de voz não permitido neste navegador.',
        'no-speech': '',
        'audio-capture': 'Nenhum microfone disponível.',
        network: 'O reconhecimento de voz precisa de internet neste navegador.',
        aborted: '',
      };
      const message = map[ev.error] ?? `Erro de voz: ${ev.error}`;
      if (['not-allowed', 'service-not-allowed', 'audio-capture'].includes(ev.error)) this.wantListening = false;
      if (message) this.emit('error', { code: ev.error, message });
    };
    rec.onend = () => {
      this.listening = false;
      this.emit('listening', false);
      if (this.paused) return;
      if (this.continuous && this.wantListening) {
        setTimeout(() => {
          if (this.wantListening && !this.listening) this.#begin();
        }, this.restartDelay);
      } else this.wantListening = false;
    };
    try {
      rec.start();
    } catch (err) {
      this.wantListening = false;
      this.emit('error', { code: 'START', message: 'Não foi possível iniciar o microfone.' });
    }
  }

  stopListening({ cancel = false } = {}) {
    this.wantListening = false;
    if (this._rec) {
      const r = this._rec;
      if (!r.stopping) {
        r.stopping = true;
        r.cancel = cancel;
        try { r.mr?.state !== 'inactive' ? r.mr?.stop() : null; } catch { /* ignora */ }
        if (!r.mr) this._rec = null;
      }
      return;
    }
    try {
      this.rec?.stop();
    } catch {
      /* ignora */
    }
  }
}
