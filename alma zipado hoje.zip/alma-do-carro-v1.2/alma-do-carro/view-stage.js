/**
 * Bolt em tela cheia: só a carinha grande do robô, a última fala dele e um botão de microfone.
 * Abre tocando no Bolt do painel (ou pelo botão da janela de conversa) e fecha no X, no botão
 * "voltar" da multimídia ou na tecla Esc. Pode abrir sozinho quando o Bolt começa a falar.
 */
import { h, ic, toast } from './ui.js';
import { createMascot, MASCOT_LABELS } from './mascot.js';

export function createBoltStage(ctx) {
  const { assistant, voice, settings } = ctx;
  let open = false;
  let auto = false; // aberto sozinho (fecha sozinho depois da fala)
  let pushed = false;
  let enteredFs = false;
  let wake = null;
  let autoCloseT = null;
  let heard = '';

  const mascot = createMascot({ size: 320, state: assistant.state });
  const name = h('strong', {}, assistant.name);
  const stateTxt = h('small', {}, MASCOT_LABELS[assistant.state]);
  const said = h('p', { class: 'stg-said', 'aria-live': 'polite' });
  const you = h('p', { class: 'stg-you' });
  const micBtn = h('button', { type: 'button', class: 'stg-mic', 'aria-label': 'Falar com o Bolt', on: { click: () => talk() } }, ic('mic', 34));
  const voiceBtn = h('button', { type: 'button', class: 'stg-btn', on: { click: () => { const v = !settings.get('assistant.voiceEnabled', true); settings.set('assistant.voiceEnabled', v); if (!v) voice.cancelSpeech(); paintVoice(); } } });
  const chatBtn = h('button', { type: 'button', class: 'stg-btn', 'aria-label': 'Abrir a conversa', title: 'Conversa', on: { click: () => { close(); ctx.widget?.open?.(); } } }, ic('list', 26));
  const closeBtn = h('button', { type: 'button', class: 'stg-close', 'aria-label': 'Fechar tela cheia', title: 'Fechar', on: { click: () => close() } }, ic('x', 34));
  const face = h('button', { type: 'button', class: 'stg-face', 'aria-label': 'Toque para falar', on: { click: () => talk() } }, mascot);

  const el = h('div', { class: 'bolt-stage', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Bolt em tela cheia', hidden: true },
    h('header', { class: 'stg-top' }, h('div', { class: 'stg-title' }, name, stateTxt), h('div', { class: 'stg-actions' }, voiceBtn, chatBtn, closeBtn)),
    h('div', { class: 'stg-center' }, face),
    h('footer', { class: 'stg-bottom' }, you, said, micBtn));
  document.body.append(el);

  function paintVoice() {
    const v = settings.get('assistant.voiceEnabled', true);
    voiceBtn.replaceChildren(ic(v ? 'volume' : 'volume-off', 26));
    voiceBtn.setAttribute('aria-label', v ? 'Voz ligada (toque para silenciar)' : 'Voz desligada');
    voiceBtn.classList.toggle('is-off', !v);
  }

  function lastSaid() {
    const m = [...assistant.messages].reverse().find((x) => x.role === 'assistant');
    return m ? m.text.replace(/\n+\(IA indisponível[^)]*\)/, '') : `Olá! Sou o ${assistant.name}. Toque em mim ou no microfone para conversar.`;
  }

  function paint() {
    const s = assistant.enabled ? assistant.state : 'normal';
    mascot.setState(s);
    mascot.classList.toggle('is-off', !assistant.enabled);
    name.textContent = assistant.name;
    stateTxt.textContent = assistant.enabled ? MASCOT_LABELS[s] : 'Assistente desligado';
    el.dataset.state = s;
    said.textContent = lastSaid();
    you.textContent = heard;
    you.hidden = !heard;
    micBtn.classList.toggle('is-on', voice.listening);
    micBtn.hidden = !assistant.enabled;
    paintVoice();
  }

  function talk() {
    if (!assistant.enabled) return toast('O assistente está desligado.', 'warn');
    if (!voice.sttSupported) return toast(ctx.gemini?.hasKey ? 'Este aparelho não libera o microfone para o app.' : 'Reconhecimento de voz indisponível aqui. Cole a chave do Gemini em Configurações para ouvir pela nuvem.', 'warn');
    cancelAutoClose();
    auto = false;
    if (voice.listening) voice.stopListening();
    else { voice.cancelSpeech(); voice.startListening({ mode: 'tap' }); }
  }

  async function show({ automatic = false } = {}) {
    cancelAutoClose();
    if (open) { if (!automatic) auto = false; return; }
    open = true;
    auto = automatic;
    heard = '';
    el.hidden = false;
    requestAnimationFrame(() => el.classList.add('in'));
    document.documentElement.classList.add('stage-open');
    paint();
    // o botão "voltar" da multimídia fecha a tela cheia em vez de sair do app
    try { history.pushState({ boltStage: true }, ''); pushed = true; } catch { pushed = false; }
    // esconde as barras do sistema (só funciona quando aberto por um toque)
    if (!automatic && document.fullscreenElement == null && document.documentElement.requestFullscreen) {
      try { await document.documentElement.requestFullscreen({ navigationUI: 'hide' }); enteredFs = true; } catch { enteredFs = false; }
    }
    try { wake = await navigator.wakeLock?.request('screen'); } catch { wake = null; }
    if (!automatic) closeBtn.focus({ preventScroll: true });
  }

  function close({ fromPop = false } = {}) {
    if (!open) return;
    open = false;
    auto = false;
    cancelAutoClose();
    el.classList.remove('in');
    document.documentElement.classList.remove('stage-open');
    setTimeout(() => { if (!open) el.hidden = true; }, 220);
    if (pushed && !fromPop) { pushed = false; try { history.back(); } catch { /* ignora */ } }
    pushed = false;
    if (enteredFs && document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    enteredFs = false;
    try { wake?.release(); } catch { /* ignora */ }
    wake = null;
  }

  function cancelAutoClose() {
    clearTimeout(autoCloseT);
    autoCloseT = null;
  }

  window.addEventListener('popstate', () => { if (open) close({ fromPop: true }); });
  document.addEventListener('keydown', (e) => { if (open && e.key === 'Escape') close(); });
  document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement) enteredFs = false; });

  assistant.on('state', (s) => {
    if (open) paint();
    // abre sozinho quando o Bolt começa a falar e fecha alguns segundos depois de terminar
    if (!settings.get('assistant.autoStage', false) || !assistant.enabled) return;
    if (s === 'speaking' && !open && !document.querySelector('.overlay')) show({ automatic: true });
    if (open && auto && s !== 'speaking' && s !== 'thinking' && s !== 'listening') {
      cancelAutoClose();
      autoCloseT = setTimeout(() => { if (auto) close(); }, 6000);
    }
  });
  assistant.on('messages', () => { if (open) paint(); });
  voice.on('listening', (on) => { if (on) heard = ''; if (open) paint(); });
  voice.on('result', ({ text }) => { heard = text; if (open) paint(); });
  settings.on('change', (p) => { if (open && (p.startsWith('assistant.') || p === 'driver.name')) paint(); });

  return {
    open: () => show(),
    close: () => close(),
    toggle: () => (open ? close() : show()),
    get isOpen() { return open; },
  };
}
