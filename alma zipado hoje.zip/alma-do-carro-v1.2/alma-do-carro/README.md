# Alma do Carro (Bolt Performance + Alma)

Abra `Alma_do_Carro.html` direto no Chrome, ou publique esta pasta no GitHub Pages e abra o endereço na multimídia.
Este projeto-fonte (módulos ES) roda por `node server.js` ou qualquer servidor estático; o arquivo único é gerado por
`node bundle.mjs . Alma_do_Carro.html`.

## Voz na multimídia (novo na 1.2)

Muitas multimídias não têm motor de voz (Text-to-Speech) nem reconhecimento de voz do Google, por isso o Bolt ficava mudo.
Agora ele pode usar o **Gemini**:

1. Crie uma chave em https://aistudio.google.com → "Get API key".
2. No app: **Configurações → Gemini (voz e IA pela nuvem)** → cole a chave → "Testar chave".
3. Em **Configurações → Assistente → Motor de voz**, deixe "Automático" (ou "Gemini (nuvem)").
4. Toque uma vez na tela depois de abrir o app: o Android só libera o som depois de um toque.

Com a chave:
- **Fala**: o texto vira um áudio (WAV) e toca como mídia comum, pelo mesmo caminho do YouTube e do rádio.
  Falas curtas repetidas (alertas, reações) ficam guardadas no aparelho e tocam até sem internet.
- **Microfone**: se a multimídia não tiver reconhecimento de voz, toque no microfone, fale, e o Gemini transcreve.
  A escuta contínua pelo nome ("Ei, Bolt") só existe com o reconhecimento do Google.
- **Conversa**: o Bolt responde com a IA do Gemini, sem precisar de servidor.

A chave fica **só no aparelho** (não vai para o GitHub nem para o backup). O uso conta na cota do seu Google AI Studio.

## Bolt em tela cheia e carinhas

- Toque no Bolt do Painel (ou no ícone de raio na janela de conversa) para abrir o robô em tela cheia.
  Fecha no **X**, no botão **voltar** da multimídia ou na tecla Esc. No meio da tela, toque no rosto ou no microfone para falar.
- Opcional: **Configurações → Assistente → "Abrir o Bolt em tela cheia quando ele falar"**.
- **Configurações → Carinha do robô**: 6 rostos prontos (Clássico, Bolinha, Visor, Painel de LED, Sorriso, Ciclope)
  e o botão **Importar carinha** (PNG, JPG, SVG, GIF ou WebP, até 1,5 MB; PNG com fundo transparente fica melhor).

## Outros

- Fotos do veículo: botão "Foto" no painel ou Garagem > editar > Aparência. Ficam só no aparelho.
- IA: ordem de uso = IA do Claude (dentro do Claude) → backend (`server.js`, se a URL estiver preenchida) → Gemini direto → falas locais.
- Voz: Configurações > Assistente > "Testar voz" diz qual motor foi usado e o motivo se a voz não sair.
