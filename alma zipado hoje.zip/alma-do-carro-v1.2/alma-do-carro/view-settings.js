/** Configurações: motorista, aparência, orientação, assistente, IA/privacidade, OBD2, alertas, dados. */
import { ACCENTS } from './config.js';
import { PERSONALITIES, LEVELS } from './assistant.js';
import { buildAiContext } from './ai-service.js';
import { Database } from './database.js';
import { APP } from './config.js';
import { h, ic, card, badge, button, field, input, select, toggle, segmented, modal, toast, confirmDialog, clear, guardMotion } from './ui.js';
import { fmtNum, downloadText } from './utils.js';
import { GEMINI_VOICES } from './gemini.js';
import { createMascot, listFaces, addCustomFace, removeCustomFace, applyFace, currentFaceId } from './mascot.js';

const row = (title, desc, control) => h('div', { class: 'pref-row' }, h('div', {}, h('strong', {}, title), desc ? h('small', {}, desc) : null), control);

export function mountSettings(root, ctx) {
  const { settings, voice } = ctx;
  const cleanups = [];
  const host = h('div', { class: 'view-settings' });
  const content = h('div', { class: 'settings-content' });
  root.append(host);
  host.append(h('div', { class: 'view-head' }, h('div', {}, h('h1', {}, 'Configurações'), h('p', {}, 'Tudo é salvo automaticamente neste dispositivo.'))), content);

  const lockBanner = h('div', { class: 'banner banner-warn', hidden: true }, ic('lock', 18), h('span', {}, 'Configurações bloqueadas com o veículo em movimento. Pare para alterar.'));
  host.insertBefore(lockBanner, content);
  const applyLock = () => {
    const locked = ctx.motionLocked();
    lockBanner.hidden = !locked;
    content.toggleAttribute('inert', locked);
    content.classList.toggle('is-locked', locked);
  };

  const set = (p) => (v) => settings.set(p, v);
  const num = (p, props = {}) => input({ type: 'number', value: settings.get(p), ...props, on: { change: (e) => settings.set(p, Number(e.target.value)) } });
  const rng = (p, min, max, step) => h('input', { type: 'range', class: 'range', min, max, step, value: settings.get(p), 'aria-label': p, on: { input: (e) => settings.set(p, Number(e.target.value)) } });

  function render() {
    clear(content);
    const s = settings;

    content.append(
      card('Motorista', { iconName: 'user' }, field('Nome', input({ value: s.get('driver.name', ''), placeholder: 'Como o carro chama você (fica só neste dispositivo)', on: { change: (e) => s.set('driver.name', e.target.value.trim()) } }))),

      card('Aparência', { iconName: 'palette' },
        row('Tema', 'Automático segue o sistema.', segmented([['dark', 'Escuro'], ['light', 'Claro'], ['auto', 'Automático']], s.get('appearance.theme'), set('appearance.theme'))),
        row('Cor de destaque', null, h('div', { class: 'swatches' }, Object.entries(ACCENTS).map(([id, a]) => h('button', { type: 'button', class: `swatch ${s.get('appearance.accent') === id ? 'on' : ''}`, style: { background: `linear-gradient(135deg, ${a.a}, ${a.b})` }, 'aria-label': a.label, title: a.label, on: { click: () => { s.set('appearance.accent', id); render(); } } }))))),

      card('Tela e navegação', { iconName: 'sliders' },
        row('Orientação', 'Automática segue o aparelho. Forçar escolhe o arranjo de tela (e tenta travar a rotação onde o navegador permite).', segmented([['auto', 'Automática'], ['landscape', 'Horizontal'], ['portrait', 'Vertical']], s.get('layout.orientation'), set('layout.orientation'))),
        row('Barra de navegação recolhida', 'Deixa só uma seta discreta para reabrir.', toggle(s.get('layout.navCollapsed'), set('layout.navCollapsed'))),
        row('Unidade de consumo', null, segmented([['kml', 'km/L'], ['l100', 'L/100 km']], s.get('display.consumptionUnit'), set('display.consumptionUnit'))),
        row('Escala do velocímetro', null, select([[180, '0–180 km/h'], [220, '0–220 km/h'], [240, '0–240 km/h'], [300, '0–300 km/h']], String(s.get('display.speedMax')), { on: { change: (e) => s.set('display.speedMax', Number(e.target.value)) } }))),

      assistantCard(),
      faceCard(),
      geminiCard(),
      aiCard(),
      obdCard(),

      card('Alertas', { iconName: 'alert' },
        h('p', { class: 'muted' }, 'Os alertas locais funcionam sem internet e sem o assistente. Limites de temperatura e rotação são definidos por veículo na Garagem.'),
        row('Alertas sonoros', null, toggle(s.get('alerts.sound'), set('alerts.sound'))),
        row('Anunciar alertas por voz', 'Depende do nível de comunicação do assistente.', toggle(s.get('assistant.announceAlerts'), set('assistant.announceAlerts'))),
        row('Aviso de combustível baixo (%)', null, num('alerts.lowFuelPct', { min: 5, max: 50, step: 1 }))),

      card('Manutenção', { iconName: 'maintenance' },
        row('Avisar quando faltar (km)', 'Margem para marcar um serviço como "próximo".', num('maintenance.warnKm', { min: 0, step: 100 })),
        row('Avisar quando faltar (dias)', null, num('maintenance.warnDays', { min: 0, step: 1 }))),

      card('Segurança ao dirigir', { iconName: 'lock' },
        row('Bloquear telas complexas em movimento', 'Formulários, limpeza de códigos e configurações ficam bloqueados acima da velocidade abaixo. A voz continua disponível.', toggle(s.get('safety.motionLock'), set('safety.motionLock'))),
        row('Velocidade de bloqueio (km/h)', null, num('safety.lockSpeedKmh', { min: 3, max: 30, step: 1 }))),

      dataCard(),
      aboutCard(),
    );
  }

  function assistantCard() {
    const s = settings;
    const voices = voice.ptVoices();
    return card('Assistente', { iconName: 'assistant' },
      row('Assistente ligado', 'Desligar não afeta o monitoramento nem os alertas locais.', toggle(s.get('assistant.enabled'), set('assistant.enabled'))),
      field('Nome do assistente', input({ value: s.get('assistant.name'), maxlength: 20, on: { change: (e) => s.set('assistant.name', e.target.value.trim() || 'Bolt') } }), { hint: 'Também é a palavra de ativação por voz.' }),
      row('Personalidade', PERSONALITIES[s.get('assistant.personality')]?.hint, segmented(Object.entries(PERSONALITIES).map(([k, v]) => [k, v.label]), s.get('assistant.personality'), (v) => { s.set('assistant.personality', v); render(); })),
      row('Nível de comunicação', LEVELS[s.get('assistant.level')]?.hint, segmented(Object.entries(LEVELS).map(([k, v]) => [k, v.label]), s.get('assistant.level'), (v) => { s.set('assistant.level', v); render(); })),
      row('Comentar sozinho o que acontece', 'Partida, motor frio, calor, bateria, rotação, velocidade, combustível, freada forte e pausas (personalidades Imponente e Debochado).', toggle(s.get('assistant.autoComment'), set('assistant.autoComment'))),
      row('Abrir o Bolt em tela cheia quando ele falar', 'Fecha sozinho alguns segundos depois. Você também abre tocando no Bolt do painel.', toggle(s.get('assistant.autoStage'), set('assistant.autoStage'))),
      h('h4', {}, 'Voz'),
      row('Voz do assistente', 'Respostas faladas.', toggle(s.get('assistant.voiceEnabled'), set('assistant.voiceEnabled'))),
      row('Motor de voz', ({ auto: 'Usa a voz do Gemini quando há chave e internet; se falhar, tenta a voz do aparelho.', cloud: 'Sempre a voz do Gemini (precisa da chave e de internet; falas repetidas ficam guardadas).', device: 'Só o motor de voz instalado no aparelho (muitas multimídias não têm).' })[s.get('assistant.voiceEngine', 'auto')],
        segmented([['auto', 'Automático'], ['cloud', 'Gemini (nuvem)'], ['device', 'Do aparelho']], s.get('assistant.voiceEngine', 'auto'), (v) => { s.set('assistant.voiceEngine', v); render(); })),
      s.get('assistant.voiceEngine', 'auto') !== 'device' ? h('div', { class: 'form-grid' },
        field('Voz do Gemini', select(GEMINI_VOICES.map(([n, d]) => [n, `${n} — ${d}`]), s.get('assistant.cloudVoice', 'Charon'), { on: { change: (e) => s.set('assistant.cloudVoice', e.target.value) } }), { hint: 'O estilo da fala acompanha a personalidade.' }),
        field('Velocidade da voz do Gemini', rng('assistant.cloudRate', 0.7, 1.4, 0.05)),
        field('Volume', rng('assistant.volume', 0, 1, 0.1))) : null,
      s.get('assistant.voiceEngine', 'auto') !== 'cloud' && voice.deviceTtsSupported ? h('div', { class: 'form-grid' },
        field('Voz do aparelho', select([['', 'Automática (pt-BR)'], ...voices.map((v) => [v.name, `${v.name} (${v.lang})`])], s.get('assistant.voiceName'), { on: { change: (e) => s.set('assistant.voiceName', e.target.value) } })),
        field('Velocidade (aparelho)', rng('assistant.rate', 0.6, 1.6, 0.05)),
        field('Tom (esquerda = voz mais grave)', rng('assistant.pitch', 0.05, 1.6, 0.05))) : null,
      h('div', { class: 'row-actions' },
        button({ label: 'Testar voz', icon: 'volume', size: 'sm', onClick: testVoice }),
        button({ label: 'Apagar falas guardadas', icon: 'trash', size: 'sm', kind: 'ghost', onClick: async () => { await voice.clearCache(); toast('Falas guardadas apagadas.', 'ok'); } })),
      h('h4', {}, 'Microfone'),
      row('Microfone', voice.browserSttSupported ? 'A permissão do microfone só é pedida no primeiro toque na tela, quando a escuta por nome está ligada.' : voice.cloudSttAvailable ? 'Este aparelho não tem reconhecimento de voz: toque no microfone, fale, e o Gemini transcreve.' : 'Sem reconhecimento de voz aqui. Com a chave do Gemini, o app ouve pela nuvem.', toggle(s.get('assistant.micEnabled'), (v) => { if (v && !voice.sttSupported) { toast('Reconhecimento de voz indisponível aqui. Cole a chave do Gemini abaixo para ouvir pela nuvem.', 'warn'); render(); return; } s.set('assistant.micEnabled', v); if (!v) voice.stopListening(); })),
      row('Modo de escuta', voice.browserSttSupported ? 'No modo contínuo o assistente só reage quando ouve o nome dele (experimental; no Chrome usa serviço online e consome bateria).' : 'Pela nuvem só funciona "Toque para falar" (gravar sem parar gastaria sua cota do Gemini).', segmented([['tap', 'Toque para falar'], ['continuous', 'Contínuo por nome']], s.get('assistant.listenMode'), (v) => { s.set('assistant.listenMode', v); voice.stopListening(); })),
      button({ label: 'Apagar conversa', icon: 'trash', size: 'sm', kind: 'ghost', onClick: async () => { await ctx.assistant.clearHistory(); toast('Conversa apagada.', 'ok'); } }));
  }

  function testVoice() {
    const s = settings;
    const nm = (s.get('driver.name', '') || '').trim();
    voice.lastError = null;
    const eng = voice.engine;
    if (!eng) return toast(voice.cloudTtsAvailable || voice.deviceTtsSupported ? 'A voz está desligada ou indisponível no motor escolhido.' : 'Este aparelho não tem motor de voz. Cole a chave do Gemini no cartão "Gemini" para o Bolt falar pela nuvem.', 'warn', 7000);
    if (!s.get('assistant.voiceEnabled', true)) return toast('A voz do assistente está desligada.', 'warn');
    toast(eng === 'cloud' ? 'Gerando a voz no Gemini…' : 'Falando pela voz do aparelho…', 'info', 2500);
    voice.speak(`Sistemas online. Sou o ${s.get('assistant.name')}, e estou com você${nm ? `, ${nm}` : ''}.`, { engine: eng });
    setTimeout(() => {
      if (voice.speaking) return;
      const why = voice.lastError;
      if (eng === 'cloud' && why) toast(`A voz do Gemini não saiu: ${why}`, 'warn', 7000);
      else if (eng === 'device' && (why || !voice.ptVoices().length)) toast(!voice.ptVoices().length ? 'Nenhuma voz em português neste aparelho. Use o motor "Gemini (nuvem)" ou instale o "Google Text-to-Speech".' : `A voz não saiu (${why}). Confira o volume de mídia e o mecanismo de voz do Android.`, 'warn', 7000);
    }, eng === 'cloud' ? 9000 : 4200);
  }

  function faceCard() {
    const s = settings;
    const cur = currentFaceId();
    const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/svg+xml,image/gif,image/webp', hidden: true, on: { change: async (e) => {
      const f = e.target.files?.[0];
      e.target.value = '';
      if (!f) return;
      try {
        const face = await addCustomFace(ctx.db, f);
        s.set('assistant.face', face.id);
        applyFace(face.id);
        toast('Carinha importada.', 'ok');
        render();
      } catch (err) { toast(err.message, 'error'); }
    } } });
    const grid = h('div', { class: 'face-grid', role: 'radiogroup', 'aria-label': 'Carinha do robô' },
      listFaces().map((f) => h('div', { class: `face-opt ${f.id === cur ? 'is-sel' : ''}`, role: 'radio', tabindex: '0', 'aria-checked': f.id === cur ? 'true' : 'false', title: f.desc,
        on: { click: () => { s.set('assistant.face', f.id); applyFace(f.id); render(); }, keydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.currentTarget.click(); } } } },
        createMascot({ size: 76, state: 'speaking', face: f.id }), h('strong', {}, f.label), h('small', {}, f.desc),
        f.custom ? h('button', { type: 'button', class: 'icon-btn icon-btn-ghost face-del', 'aria-label': `Excluir ${f.label}`, title: 'Excluir', on: { click: async (e) => { e.stopPropagation(); if (await confirmDialog({ title: 'Excluir carinha?', message: `"${f.label}" será removida deste aparelho.`, confirmLabel: 'Excluir', danger: true })) { await removeCustomFace(ctx.db, f.id); if (s.get('assistant.face') === f.id) s.set('assistant.face', 'classic'); render(); } } } }, ic('trash', 16)) : null)));
    return card('Carinha do robô', { iconName: 'bolt' },
      h('p', { class: 'muted' }, 'Escolha o rosto do Bolt. Todas reagem quando ele ouve, pensa, fala e dá alertas. Você pode importar a sua (PNG com fundo transparente fica melhor; até 1,5 MB).'),
      grid,
      h('div', { class: 'row-actions' }, button({ label: 'Importar carinha', icon: 'upload', size: 'sm', onClick: () => file.click() }), file));
  }

  function geminiCard() {
    const s = settings;
    let shown = false;
    const key = input({ type: 'password', value: s.get('gemini.apiKey', ''), placeholder: 'Cole aqui a chave (começa com AIza…)', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Chave da API do Gemini', on: { change: (e) => { s.set('gemini.apiKey', e.target.value.trim()); render(); } } });
    const eye = button({ icon: 'info', size: 'sm', kind: 'ghost', title: 'Mostrar/ocultar chave', onClick: () => { shown = !shown; key.type = shown ? 'text' : 'password'; } });
    const result = h('div', { class: 'ai-result muted' }, ctx.gemini.hasKey ? 'Chave salva neste aparelho.' : 'Sem chave: o Bolt usa a voz e o reconhecimento do aparelho (se existirem) e respostas locais.');
    const test = async () => {
      if (!ctx.gemini.hasKey) return toast('Cole a chave primeiro.', 'warn');
      result.textContent = 'Testando…';
      try {
        const t = await ctx.gemini.ask('Responda apenas: ok', { temperature: 0 });
        clear(result).append(badge('Chave funcionando', 'ok'), h('small', {}, ` Conversa: ${ctx.gemini.working.text?.model || '?'} · resposta "${t.slice(0, 20)}"`));
      } catch (err) {
        clear(result).append(badge('Falhou', 'warn'), h('small', {}, ` ${err.message}`));
      }
    };
    return card('Gemini (voz e IA pela nuvem)', { iconName: 'globe' },
      h('p', { class: 'muted' }, 'Com a chave, o Bolt fala com a voz do Gemini (toca como áudio comum, igual YouTube e rádio, sem depender do motor de voz da multimídia), ouve pelo microfone mesmo sem reconhecimento do Google e conversa com a IA. A chave fica SÓ neste aparelho: não vai para o GitHub nem para o backup. Crie a sua em aistudio.google.com → "Get API key".'),
      h('div', { class: 'gemini-key' }, key, eye),
      h('div', { class: 'row-actions' }, button({ label: 'Testar chave', icon: 'refresh', size: 'sm', onClick: test }), s.get('gemini.apiKey') ? button({ label: 'Remover chave', icon: 'trash', size: 'sm', kind: 'ghost', onClick: () => { s.set('gemini.apiKey', ''); render(); } }) : null),
      result,
      row('Conversar pela IA do Gemini', 'Desligado: o Bolt fala com a voz do Gemini, mas responde com falas locais (ou pelo backend, se configurado).', toggle(s.get('gemini.chat', true), set('gemini.chat'))),
      h('small', { class: 'muted' }, 'O uso da API conta na sua cota do Google AI Studio (há uma faixa gratuita com limites). Falas curtas repetidas, como alertas, ficam guardadas e não gastam de novo.'));
  }

  function aiCard() {
    const s = settings;
    const result = h('div', { class: 'ai-result muted' }, 'Não verificado.');
    const check = async () => {
      result.textContent = 'Verificando…';
      const hlt = await ctx.ai.check();
      clear(result).append(badge(hlt.ok ? (hlt.ai ? 'IA disponível' : 'Backend ativo, sem chave de IA') : 'Backend inacessível', hlt.ai ? 'ok' : 'warn'), h('small', {}, ` ${hlt.reason}`));
    };
    const preview = () => {
      const ctxJson = buildAiContext({ settings: s, engine: ctx.engine, vehicle: ctx.garage.active(), alerts: ctx.alerts.list(), dtcs: ctx.currentDtcs(), maintenance: [] });
      modal({ title: 'O que é enviado à IA', icon: 'shield', size: 'md', body: [h('p', {}, 'Este é o contexto que acompanha cada pergunta (além do texto que você escreve). Placa, VIN, nome, localização e histórico de viagens nunca são enviados.'), h('pre', { class: 'json-preview' }, JSON.stringify(ctxJson, null, 2))] });
    };
    return card('IA e privacidade', { iconName: 'shield' },
      h('p', { class: 'muted' }, 'Ordem da conversa: IA do Claude (quando o app roda dentro do Claude) → backend, se a URL abaixo estiver preenchida → Gemini direto (cartão acima) → respostas locais. No backend a chave fica só no servidor.'),
      field('URL do backend', input({ value: s.get('ai.backendUrl'), placeholder: 'Vazio = mesmo servidor que entrega este app', on: { change: (e) => { s.set('ai.backendUrl', e.target.value.trim()); } } })),
      h('div', { class: 'row-actions' }, button({ label: 'Testar conexão', icon: 'refresh', size: 'sm', onClick: check }), result),
      h('h4', {}, 'O que pode ser enviado'),
      row('Meu nome (para o carro me chamar pelo nome)', 'Usado apenas na conversa com a IA do Claude, para a alma falar com você pelo nome.', toggle(s.get('ai.shareDriverName'), set('ai.shareDriverName'))),
      row('Perfil do veículo (marca, modelo, motor)', null, toggle(s.get('ai.shareVehicleProfile'), set('ai.shareVehicleProfile'))),
      row('Dados ao vivo (velocidade, temperatura…)', null, toggle(s.get('ai.shareLiveData'), set('ai.shareLiveData'))),
      row('Códigos de falha (DTC)', null, toggle(s.get('ai.shareDiagnostics'), set('ai.shareDiagnostics'))),
      row('Resumo da manutenção', null, toggle(s.get('ai.shareMaintenance'), set('ai.shareMaintenance'))),
      button({ label: 'Ver exatamente o que é enviado', icon: 'info', size: 'sm', kind: 'ghost', onClick: preview }));
  }

  function obdCard() {
    const s = settings;
    const avail = ctx.obd.availability(window);
    return card('OBD2', { iconName: 'obd' },
      h('ul', { class: 'avail-list' }, avail.map((a) => h('li', {}, ic(a.icon, 18), h('div', {}, h('strong', {}, a.label), h('small', {}, a.supported ? a.description : a.reason)), badge(a.supported ? 'Suportado aqui' : 'Indisponível', a.supported ? 'ok' : 'neutral')))),
      row('Adaptador preferido', null, select(avail.map((a) => [a.kind, a.label]), s.get('obd.preferred'), { on: { change: (e) => s.set('obd.preferred', e.target.value) } })),
      row('Reconectar automaticamente', 'Tenta de novo com intervalos crescentes se a conexão cair.', toggle(s.get('obd.autoReconnect'), set('obd.autoReconnect'))),
      button({ label: 'Abrir conexão OBD2', icon: 'link', size: 'sm', onClick: () => ctx.openObdDialog() }),
      h('p', { class: 'muted' }, 'A Alma do Carro opera em modo somente leitura: não programa a ECU nem envia comandos não documentados.'));
  }

  function dataCard() {
    const file = h('input', { type: 'file', accept: 'application/json,.json', hidden: true, on: { change: onImport } });
    const usage = h('small', { class: 'muted' }, 'Calculando uso…');
    ctx.db.usage().then((u) => { usage.textContent = u.usage != null ? `Uso de armazenamento: ${fmtNum(u.usage / 1024, 0)} KB${u.quota ? ` de ${fmtNum(u.quota / 1048576, 0)} MB disponíveis` : ''}.` : 'Uso de armazenamento indisponível.'; });
    async function onImport(e) {
      const f = e.target.files?.[0];
      e.target.value = '';
      if (!f || !guardMotion(ctx)) return;
      let payload;
      try { payload = JSON.parse(await f.text()); } catch { return toast('Arquivo inválido.', 'error'); }
      const v = Database.validateBackup(payload);
      if (!v.ok) return toast(v.error, 'error');
      const replace = await confirmDialog({ title: 'Como restaurar?', message: 'MESCLAR mantém seus dados atuais e adiciona/atualiza os do backup (recomendado). SUBSTITUIR apaga os dados atuais antes de restaurar.', confirmLabel: 'Substituir tudo', cancelLabel: 'Mesclar', danger: true, icon: 'database' });
      try {
        if (replace && !(await confirmDialog({ title: 'Substituir todos os dados?', message: 'Os dados locais atuais serão apagados e trocados pelo backup.', confirmLabel: 'Substituir', danger: true, requireText: 'SUBSTITUIR' }))) return;
        const r = await ctx.db.importAll(payload, { mode: replace ? 'replace' : 'merge' });
        await ctx.reloadAll();
        toast(`Backup restaurado (${r.imported} registros).`, 'ok');
      } catch (err) { toast(err.message, 'error'); }
    }
    return card('Dados e backup', { iconName: 'database' },
      ctx.volatile ? h('div', { class: 'banner banner-warn' }, ic('alert', 18), h('span', {}, 'Armazenamento persistente indisponível: os dados desta sessão serão perdidos ao fechar.')) : null,
      h('p', { class: 'muted' }, 'Tudo fica neste dispositivo. O backup não inclui o token da ponte Wi-Fi nem a chave do Gemini.'),
      h('div', { class: 'row-actions' },
        button({ label: 'Exportar backup', icon: 'download', onClick: async () => { const b = await ctx.db.exportAll(); b.stores.settings = (b.stores.settings || []).map((r) => (r.key === 'app' ? { ...r, value: { ...r.value, obd: { ...(r.value?.obd || {}), bridgeToken: '' }, gemini: { ...(r.value?.gemini || {}), apiKey: '' } } } : r)); downloadText(`bolt-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(b)); toast('Backup exportado.', 'ok'); } }),
        button({ label: 'Restaurar backup', icon: 'upload', onClick: () => file.click() }), file),
      usage,
      h('div', { class: 'row-actions' },
        button({ label: 'Restaurar configurações padrão', kind: 'ghost', size: 'sm', onClick: async () => { await settings.reset(); render(); toast('Configurações restauradas.', 'ok'); } }),
        button({ label: 'Apagar todos os dados locais', icon: 'trash', kind: 'danger', size: 'sm', onClick: async () => { if (!guardMotion(ctx)) return; if (await confirmDialog({ title: 'Apagar tudo?', message: 'Veículos, viagens, serviços, falhas, alertas e configurações deste dispositivo serão apagados definitivamente. Exporte um backup antes.', confirmLabel: 'Apagar tudo', danger: true, requireText: 'APAGAR' })) { await ctx.wipeAll(); } } })));
  }

  function aboutCard() {
    const p = ctx.platform;
    const yes = (v) => badge(v ? 'Sim' : 'Não', v ? 'ok' : 'neutral');
    return card('Sobre este dispositivo', { iconName: 'info' },
      h('p', {}, `${APP.name} ${APP.version}`),
      h('ul', { class: 'avail-list compact' }, [['Contexto seguro (HTTPS/localhost)', p.secureContext], ['Web Bluetooth (BLE)', p.webBluetooth], ['Reconhecimento de voz', p.speechRecognition], ['Síntese de voz', p.speechSynthesis], ['Geolocalização', p.geolocation], ['Armazenamento local (IndexedDB)', p.indexedDB], ['Funciona offline (Service Worker)', p.serviceWorker], ['Ponte nativa (BoltNative)', p.native.present]].map(([l, v]) => h('li', {}, h('span', {}, l), yes(v)))));
  }

  render();
  applyLock();
  cleanups.push(ctx.onTick(applyLock), voice.on('voices', () => {}));
  return { destroy: () => cleanups.forEach((c) => c && c()) };
}
