/**
 * Mascote da ALMA DO CARRO, com várias "carinhas" que podem ser trocadas em Configurações.
 * Todas reagem aos mesmos estados: sleeping (motor desligado), normal, listening, thinking,
 * speaking, attention, alert. As animações vivem em styles.css (seletor .bolt-mascot[data-state]).
 *
 * Como uma carinha é feita (viewBox 0 0 64 56):
 *   .m-eye  (+ .m-eye-l / .m-eye-r)  olhos: respiram, piscam ao pensar, pulsam ao falar
 *   .m-bar  (com --i)                 barras da boca/voz: aparecem ao ouvir e ao falar
 *   .m-line / .m-fill                 detalhes (contorno da cabeça, visor, antena)
 *   .m-smile                          some enquanto as barras aparecem
 *   .m-img                            imagem importada pelo usuário
 * Carinhas importadas (PNG, JPG, SVG, GIF, WebP) ficam guardadas só neste aparelho.
 */

export const MASCOT_STATES = ['sleeping', 'normal', 'listening', 'thinking', 'speaking', 'attention', 'alert'];

export const MASCOT_LABELS = {
  sleeping: 'Em espera',
  normal: 'Pronto',
  listening: 'Ouvindo',
  thinking: 'Pensando',
  speaking: 'Falando',
  attention: 'Atenção',
  alert: 'Alerta',
};

const bars = (xs, { y = 40, h = 10, w = 2.8, rx = 1.4 } = {}) => xs.map((x, i) => `<rect class="m-bar" style="--i:${i}" x="${x - w / 2}" y="${y}" width="${w}" height="${h}" rx="${rx}"/>`).join('');
const BARS = [18, 23, 28, 33, 38, 43, 48];
const ledEye = (cls, x0, y0) => {
  let r = '';
  for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) if (!(row === 0 && (col === 0 || col === 2))) r += `<rect x="${x0 + col * 5}" y="${y0 + row * 5}" width="4" height="4" rx=".6"/>`;
  return `<g class="m-eye ${cls}">${r}</g>`;
};

/** Carinhas que já vêm no app. */
export const FACES = [
  {
    id: 'classic',
    label: 'Clássico',
    desc: 'Os olhos angulares originais do Bolt.',
    inner: () =>
      '<polygon class="m-eye m-eye-l" points="2,12 29,19 26,34 4,28"/>' +
      '<polygon class="m-eye m-eye-r" points="62,12 35,19 38,34 60,28"/>' +
      `<g class="m-mouth">${bars(BARS)}</g>`,
  },
  {
    id: 'orb',
    label: 'Bolinha',
    desc: 'Robozinho redondo com antena.',
    inner: () =>
      '<line class="m-line" x1="32" y1="8" x2="32" y2="3"/><circle class="m-fill m-ant" cx="32" cy="2.5" r="2.4"/>' +
      '<circle class="m-line" cx="32" cy="30" r="22"/>' +
      '<circle class="m-eye m-eye-l" cx="23" cy="26" r="5.5"/><circle class="m-eye m-eye-r" cx="41" cy="26" r="5.5"/>' +
      '<path class="m-line m-smile" d="M25 39 Q32 44 39 39"/>' +
      `<g class="m-mouth">${bars([23, 27.5, 32, 36.5, 41], { y: 37, h: 8, w: 2.6 })}</g>`,
  },
  {
    id: 'visor',
    label: 'Visor',
    desc: 'Capacete com visor de luz.',
    inner: () =>
      '<rect class="m-line" x="5" y="6" width="54" height="44" rx="12"/>' +
      '<rect class="m-fill" x="10" y="15" width="44" height="16" rx="8"/>' +
      '<rect class="m-eye m-eye-l" x="15" y="19" width="13" height="8" rx="4"/><rect class="m-eye m-eye-r" x="36" y="19" width="13" height="8" rx="4"/>' +
      `<g class="m-mouth">${bars([20, 24, 28, 32, 36, 40, 44], { y: 37, h: 8, w: 2.4 })}</g>`,
  },
  {
    id: 'led',
    label: 'Painel de LED',
    desc: 'Olhos de pixels, estilo letreiro.',
    inner: () =>
      ledEye('m-eye-l', 8, 12) + ledEye('m-eye-r', 42, 12) +
      `<g class="m-mouth">${bars([17, 22, 27, 32, 37, 42, 47], { y: 38, h: 10, w: 4, rx: 0.6 })}</g>`,
  },
  {
    id: 'capsule',
    label: 'Sorriso',
    desc: 'Olhos de cápsula e um sorriso.',
    inner: () =>
      '<rect class="m-eye m-eye-l" x="16" y="8" width="11" height="22" rx="5.5"/><rect class="m-eye m-eye-r" x="37" y="8" width="11" height="22" rx="5.5"/>' +
      '<path class="m-line m-smile" d="M20 39 Q32 49 44 39"/>' +
      `<g class="m-mouth">${bars(BARS)}</g>`,
  },
  {
    id: 'cyclops',
    label: 'Ciclope',
    desc: 'Um olho só, grande e atento.',
    inner: () =>
      '<circle class="m-line" cx="32" cy="22" r="17"/><circle class="m-fill" cx="32" cy="22" r="12.5"/>' +
      '<circle class="m-eye m-eye-l" cx="32" cy="22" r="7.5"/>' +
      `<g class="m-mouth">${bars([20, 24, 28, 32, 36, 40, 44], { y: 44, h: 9, w: 2.6 })}</g>`,
  },
];

/* ------------------------------------------------------------ carinhas importadas */

const KV_KEY = 'faces.custom';
const MAX_BYTES = 1.5 * 1024 * 1024;
const OK_TYPES = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/gif', 'image/webp'];
let customFaces = [];
let currentFace = 'classic';
const live = new Set();

export function listFaces() {
  return [...FACES.map((f) => ({ id: f.id, label: f.label, desc: f.desc, custom: false })), ...customFaces.map((f) => ({ id: f.id, label: f.label, desc: 'Importada', custom: true }))];
}

export async function loadCustomFaces(db) {
  try {
    const row = await db.get('kv', KV_KEY);
    customFaces = Array.isArray(row?.value) ? row.value.filter((f) => f && f.id && typeof f.dataUrl === 'string' && /^data:image\//.test(f.dataUrl)) : [];
  } catch {
    customFaces = [];
  }
  return customFaces;
}

/** Importa uma imagem como carinha. Devolve a carinha criada. */
export async function addCustomFace(db, file, label = '') {
  if (!file) throw new Error('Nenhum arquivo escolhido.');
  if (!OK_TYPES.includes(file.type)) throw new Error('Use uma imagem PNG, JPG, SVG, GIF ou WebP.');
  if (file.size > MAX_BYTES) throw new Error('Imagem grande demais (máximo 1,5 MB).');
  const dataUrl = await new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
    r.readAsDataURL(file);
  });
  const face = { id: `custom:${Date.now().toString(36)}`, label: (label || file.name.replace(/\.[^.]+$/, '')).slice(0, 24) || 'Minha carinha', dataUrl };
  customFaces = [...customFaces, face];
  await db.put('kv', { key: KV_KEY, value: customFaces });
  return face;
}

export async function removeCustomFace(db, id) {
  customFaces = customFaces.filter((f) => f.id !== id);
  await db.put('kv', { key: KV_KEY, value: customFaces });
  if (currentFace === id) applyFace('classic');
}

/** Troca a carinha de todos os mascotes da tela. */
export function applyFace(id) {
  currentFace = FACES.some((f) => f.id === id) || customFaces.some((f) => f.id === id) ? id : 'classic';
  const now = Date.now();
  for (const w of [...live]) {
    if (!w.isConnected && now - w._born > 5000) { live.delete(w); continue; }
    paint(w, w._faceFixed || currentFace);
  }
  return currentFace;
}

export function currentFaceId() {
  return currentFace;
}

const NS = 'http://www.w3.org/2000/svg';

function paint(wrap, faceId) {
  const svg = wrap.firstChild;
  while (svg.firstChild) svg.removeChild(svg.firstChild);
  const custom = customFaces.find((f) => f.id === faceId);
  const face = custom ? null : FACES.find((f) => f.id === faceId) || FACES[0];
  wrap.dataset.face = custom ? 'custom' : face.id;
  if (custom) {
    const img = document.createElementNS(NS, 'image');
    img.setAttribute('class', 'm-img');
    img.setAttribute('x', '0');
    img.setAttribute('y', '0');
    img.setAttribute('width', '64');
    img.setAttribute('height', '50');
    img.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    img.setAttribute('href', custom.dataUrl);
    svg.appendChild(img);
    const g = document.createElementNS(NS, 'g');
    g.setAttribute('class', 'm-mouth');
    svg.appendChild(g);
    appendMarkup(g, bars([24, 28, 32, 36, 40], { y: 50, h: 5, w: 2.4, rx: 1.2 }));
    return;
  }
  appendMarkup(svg, face.inner());
}

function appendMarkup(parent, markup) {
  const doc = new DOMParser().parseFromString(`<svg xmlns="${NS}">${markup}</svg>`, 'image/svg+xml');
  for (const n of [...doc.documentElement.childNodes]) parent.appendChild(document.importNode(n, true));
}

/** Marcação interna da carinha clássica (usada por quem precisa só do desenho). */
export function mascotInner() {
  return FACES[0].inner();
}

/** SVG estático (estado normal) para o arquivo bolt-mascot.svg. */
export function mascotSvgString() {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 56" width="256" height="224">
<rect width="64" height="56" rx="10" fill="#07131C"/>
<polygon points="2,12 29,19 26,34 4,28" fill="#3EE2FF"/><polygon points="62,12 35,19 38,34 60,28" fill="#3EE2FF"/>
</svg>`;
}

/**
 * Cria o elemento do mascote. Retorna o <span> com método setState().
 * @param {{size?:number,state?:string,face?:string}} opts  face fixa (ex.: prévia nas Configurações); sem ela, segue a escolhida
 */
export function createMascot({ size = 44, state = 'normal', face = null } = {}) {
  const wrap = document.createElement('span');
  wrap.className = 'bolt-mascot';
  wrap.style.setProperty('--ms', `${size}px`);
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 64 56');
  svg.setAttribute('aria-hidden', 'true');
  wrap.appendChild(svg);
  wrap._born = Date.now();
  wrap._faceFixed = face;
  paint(wrap, face || currentFace);
  if (live.size > 30) for (const w of [...live]) if (!w.isConnected && Date.now() - w._born > 5000) live.delete(w);
  live.add(wrap);
  wrap.setState = (s) => {
    const next = MASCOT_STATES.includes(s) ? s : 'normal';
    if (wrap.dataset.state === next) return;
    wrap.dataset.state = next;
    wrap.setAttribute('role', 'img');
    wrap.setAttribute('aria-label', `Assistente: ${MASCOT_LABELS[next]}`);
  };
  wrap.setState(state);
  return wrap;
}
